package com.faizasqlitetugas.sqlitefaiza_table_crud.features.subject_crud;

public interface SubjectCrudListener {
    void onSubjectListUpdate(boolean isUpdate);
}
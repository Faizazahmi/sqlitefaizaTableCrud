package com.faizasqlitetugas.sqlitefaiza_table_crud.features.student_crud;

public interface StudentCrudListener {
    void onStudentListUpdate(boolean isUpdated);
}
